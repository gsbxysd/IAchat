# Chatbot com Inteligência Artificial (React + OpenAI)

Este é um projeto de site com um chatbot de IA desenvolvido com React e integrado à API da OpenAI.

## Funcionalidades

- Chat responsivo com a IA (modelo GPT-3.5-turbo).
- Interface limpa e moderna.
- IA configurada para responder sempre em **português**.
- Deploy automático via Netlify.

---

## Como usar localmente

1. **Clone o repositório**:
   ```bash
   git clone https://github.com/seu-usuario/seu-repo.git
   cd seu-repo
   ```

2. **Instale as dependências**:
   ```bash
   npm install
   ```

3. **Configure a chave da OpenAI**:
   Crie o arquivo `.env.local`:
   ```
   REACT_APP_OPENAI_KEY=sk-sua-chave-aqui
   ```

4. **Inicie o projeto**:
   ```bash
   npm start
   ```

---

## Deploy no Netlify

### Passos:

1. Faça login em [Netlify](https://netlify.com).
2. Vá em “Add new site” > “Import from Git”.
3. Conecte seu GitHub e selecione este repositório.
4. Configure:
   - Build command: `npm run build`
   - Publish directory: `build`
5. Em **Site settings > Environment variables**, adicione:
   ```
   REACT_APP_OPENAI_KEY = sk-sua-chave-aqui
   ```

Netlify fará o deploy automático a cada `git push`.

---

## Licença

Este projeto está sob a licença MIT.